	project "Bullet3Dynamics"

	language "C++"
				
	kind "StaticLib"

	includedirs {
		".."
	}		
	

	files {
		"**.cpp",
		"**.h"
	}