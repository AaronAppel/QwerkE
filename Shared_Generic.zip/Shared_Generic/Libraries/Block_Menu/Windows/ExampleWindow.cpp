#include "ExampleWindow.h"

ExampleWindow::ExampleWindow(vec2 resolution) :
	MenuWindow(resolution)
{
}

ExampleWindow::~ExampleWindow()
{
}

void ExampleWindow::Init()
{
	// Add item box
	// Add items
	// Add other buttons and setup their functionality
}